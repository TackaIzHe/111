﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using С1App.Data;

namespace С1App
{
	/// <summary>
	/// Логика взаимодействия для Tickets.xaml
	/// </summary>
	public partial class Tickets : Window
	{
		public Tickets()
		{
			InitializeComponent();
			zakazs.ItemsSource = new C1DbContext().GetZakazs();
		}

		private void onDelete(object sender, RoutedEventArgs e)
		{

        }
    }
}
