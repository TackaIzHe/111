﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using С1App.Data;

namespace С1App
{
	/// <summary>
	/// Логика взаимодействия для FormZakazaMP.xaml
	/// </summary>
	public partial class FormZakazaMP : Window
	{
		List<Item> item = new List<Item>();
		public FormZakazaMP(List<Item> strings)
		{
			InitializeComponent();
			User.Text = MainWindow.userName;
			item = strings;
			items.ItemsSource = strings;
			int total=0;
			foreach (var item in strings)
			{
				total += item.Price*item.Colichestvo;
			}
			TotalPrice.Text += total.ToString();
		}

		private void createZakaz(object sender, RoutedEventArgs e)
		{
			string items = "";
			string Coll = "";
			foreach (var item in item) 
			{
				items += item.Name + " ";
				Coll += item.Colichestvo + " ";
			}

			new C1DbContext().addZakaz(new Zakaz
			{
				UserId = MainWindow.userId.ToString(),
				Comment ="",
				Date = DateTime.Now.ToString(),
				State = "await",
				Items = items,
				Colichestvo = Coll
			});
		}
	}
}
